<div class="container">

	<div class="col-md-6 offset-3" style="margin-top: 20%;margin-bottom: 20%;">


            <div class="cartbox__buttons">
                <a class="food__btn" href="<?=base_url()?>Order/stripe_payment_form"><span>Card payment</span></a>
            </div> 

            <div class="cartbox__buttons">
                <a class="food__btn" href="<?=base_url()?>Order"><span>Cash on delivery</span></a>
            </div> 

	</div>
</div>