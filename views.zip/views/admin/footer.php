
  <footer class="main-footer">
    <strong>Copyright &copy; 2020 <a target="_blank" href="<?= base_url()?>">bdNews24</a>.</strong> All rights
    reserved.
  </footer>


</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?= base_url()?>asset/admin/bower_components/jquery/dist/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="asset/admin/bower_components/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="<?= base_url()?>asset/admin/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>


<!-- Bootstrap WYSIHTML5 -->
<script src="<?= base_url()?>asset/admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>


<!-- AdminLTE App -->
<script src="<?= base_url()?>asset/admin/dist/js/adminlte.min.js"></script>

<!-- AdminLTE for demo purposes -->
<script src="<?= base_url()?>asset/admin/dist/js/demo.js"></script>
</body>
</html>

<script>

$(document).on('change', '#offer_box', function(){
 var url = 'http://localhost/bdNews24/Manage_items/add_offer/'+$(this).val();;
 window.location = url; 
 });

</script>
